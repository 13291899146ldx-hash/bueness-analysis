# -*- coding: utf-8 -*-
from __future__ import annotations

import argparse
import csv
import html
import math
import re
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from typing import Dict, Iterable, List, Tuple


DEFAULT_INPUT = Path(r"D:\audieo\omni_scene_industry_output\场景行业产品分类汇总.csv")
DEFAULT_OUTPUT_HTML = Path(r"D:\audieo\omni_scene_industry_output\销售录音分析报告看板.html")

SCENE_ORDER = ["快速拦截场景", "正常沟通场景", "深度会谈场景", "群体影响场景"]
CUSTOMER_ORDER = ["资金紧急型", "价格敏感型", "保守观望型", "成熟借贷型", "模糊探索型", "非目标客户"]
STRATEGY_ORDER = [
    "快速筛选+推进策略",
    "客户痛点放大策略",
    "成本重构策略",
    "信任建立策略",
    "对比决策策略",
    "试探教育策略",
    "紧迫锁单策略",
    "信息留存策略",
]

SCENE_COLORS = {
    "快速拦截场景": "#cc5a2e",
    "正常沟通场景": "#2a7f98",
    "深度会谈场景": "#2f5d50",
    "群体影响场景": "#8f6a2b",
}

CUSTOMER_COLORS = {
    "资金紧急型": "#cb3a29",
    "价格敏感型": "#bf6a1f",
    "保守观望型": "#375a7f",
    "成熟借贷型": "#1f7a5c",
    "模糊探索型": "#7b5ea7",
    "非目标客户": "#6a6a6a",
}

STRATEGY_COLORS = {
    "快速筛选+推进策略": "#d1495b",
    "客户痛点放大策略": "#f28f3b",
    "成本重构策略": "#247ba0",
    "信任建立策略": "#5b8c5a",
    "对比决策策略": "#3b5dc9",
    "试探教育策略": "#8f62d6",
    "紧迫锁单策略": "#c44536",
    "信息留存策略": "#7a7d7d",
}

UNKNOWN_LABEL = "未能根据知识库判断"

THEME_RULES: Dict[str, List[Tuple[str, str, List[str]]]] = {
    "成本重构策略": [
        ("还款结构重构", "把客户注意力从表面利率转到先息后本、资金占用效率和还款结构。", ["先息后本", "只还利息", "本金", "还款"]),
        ("利率换算与总成本", "通过年化、月供、节约金额等方式重算真实成本。", ["年化", "利息", "节约", "一天", "一个月", "两点八", "万二点八", "四千五"]),
        ("额度与长期收益", "强调提额、降息、循环额度等长期价值。", ["提额", "降息", "额度", "循环", "五年", "十倍"]),
    ],
    "信任建立策略": [
        ("正规资质背书", "用银行、监管、工号、总部等信息建立平台可信度。", ["银行", "监管", "正规", "工号", "总部", "二维码", "商业银行"]),
        ("真实案例与在地证明", "用已服务客户、同城案例或熟人链接增强信任。", ["老板", "案例", "客户", "老乡", "昨天", "办了好多", "同一家公司"]),
        ("风险顾虑安抚", "围绕不收费、征信、安全、报警等顾虑做拆解和安抚。", ["不收费", "报警", "作假", "逾期", "安全", "不用", "商量", "高利贷"]),
    ],
    "试探教育策略": [
        ("授信逻辑教育", "解释额度如何批、风控为什么这样判断。", ["芝麻分", "授信", "风控", "批", "前期", "后台", "额度"]),
        ("产品机制解释", "解释随借随还、先息后本、提额等产品工作方式。", ["随借随还", "用一天算一天", "先息后本", "提额", "三五分钟", "循环"]),
        ("低压试探引导", "以先测一下、先看看、体验一下为主，不强推成交。", ["先测", "看看", "能不能用", "体验", "先看", "备用咯"]),
    ],
    "对比决策策略": [
        ("竞品差异化对比", "把本产品与微粒贷、网商贷等竞品做结构化对比。", ["微粒贷", "网商贷", "花呗", "借呗", "竞品", "比你", "对比"]),
        ("成本结构对比", "用日成本、月成本、年化成本帮助客户决策。", ["年化", "一天", "一个月", "一百多", "利息", "划算", "两千八"]),
        ("额度与使用效率", "突出循环额度、提额速度和使用效率差异。", ["循环", "额度", "提额", "拿出来用", "二十万", "马上又可以"]),
    ],
    "紧迫锁单策略": [
        ("时效催化", "强调到账速度和时间窗口，推动客户立刻决策。", ["15分钟", "最快", "马上", "现在", "立马", "今天"]),
        ("即时推进动作", "在客户仍有意愿时推动报备、签约或继续操作。", ["报备", "通过", "签约", "先做", "做下来", "打给你"]),
        ("最后顾虑清除", "在临门阶段快速拆除最后阻碍。", ["钱不到账不算利息", "不算利息", "不用担心", "只要通过"]),
    ],
    "客户痛点放大策略": [
        ("资金缺口点明", "直接放大客户周转压力与当前缺口。", ["周转", "缺钱", "资金", "压力", "材料", "进货"]),
        ("解决方案绑定", "把贷款产品和客户具体问题直接绑定。", ["解决", "用这个", "这笔钱", "拿这个", "补一下"]),
    ],
    "快速筛选+推进策略": [
        ("快速问需筛选", "快速判断客户是否需要额度、是否值得继续推进。", ["需要不", "要不要", "做个备用", "额度", "营业执照"]),
        ("目标确认后推进", "一旦判断为目标客户，就迅速推进下一步动作。", ["先做", "批下来", "马上", "刷流水", "看下额度"]),
    ],
    "信息留存策略": [
        ("礼貌退出留白", "在明确拒绝后礼貌结束，避免留下反感。", ["打扰", "好好", "以后", "备用", "不需要吗", "不打扰"]),
        ("未形成留资动作", "录音里没有明显执行加微信、留名片等后续留存动作。", ["未体现明显匹配话术"]),
    ],
}


def split_pair(value: str) -> Tuple[str, str]:
    left, sep, right = (value or "").partition("｜")
    if sep:
        return left.strip(), right.strip()
    return value.strip(), ""


def load_rows(path: Path) -> List[Dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def normalize_rows(rows: List[Dict[str, str]]) -> List[Dict[str, str]]:
    normalized: List[Dict[str, str]] = []
    for row in rows:
        scene, customer = split_pair(row.get("场景及客户类型", ""))
        industry, product = split_pair(row.get("客户行业及产品类型", ""))
        normalized.append(
            {
                **row,
                "场景": scene,
                "客户类型": customer,
                "行业类型": industry,
                "产品类型": product,
            }
        )
    return normalized


def counter_in_order(counter: Counter, order: Iterable[str]) -> List[Tuple[str, int]]:
    items = [(name, counter.get(name, 0)) for name in order if counter.get(name, 0) > 0]
    remainder = sorted([(name, count) for name, count in counter.items() if name not in set(order)], key=lambda item: (-item[1], item[0]))
    return items + remainder


def distribution_rows(items: List[Tuple[str, int]], total: int, label_name: str) -> List[Dict[str, str]]:
    return [
        {
            label_name: label,
            "数量": str(count),
            "占比": f"{(count / total * 100):.1f}%" if total else "0.0%",
        }
        for label, count in items
    ]


def build_matrix(rows: List[Dict[str, str]], row_key: str, col_key: str, row_order: List[str], col_order: List[str]) -> Tuple[List[str], List[str], Dict[Tuple[str, str], int]]:
    matrix: Dict[Tuple[str, str], int] = defaultdict(int)
    row_labels = []
    col_labels = []

    row_counter = Counter(row[row_key] for row in rows)
    col_counter = Counter(row[col_key] for row in rows)

    row_labels.extend([label for label in row_order if row_counter.get(label, 0) > 0])
    row_labels.extend([label for label, _ in sorted(row_counter.items(), key=lambda item: (-item[1], item[0])) if label not in row_labels])

    col_labels.extend([label for label in col_order if col_counter.get(label, 0) > 0])
    col_labels.extend([label for label, _ in sorted(col_counter.items(), key=lambda item: (-item[1], item[0])) if label not in col_labels])

    for row in rows:
        matrix[(row[row_key], row[col_key])] += 1
    return row_labels, col_labels, matrix


def split_script_items(text: str) -> List[str]:
    cleaned = (text or "").strip()
    if not cleaned:
        return []
    if cleaned.startswith("未体现明显匹配话术"):
        return []
    parts = [part.strip(" ；;") for part in re.split(r"\s*\d+\.\s*", cleaned) if part.strip(" ；;")]
    if parts:
        return parts
    return [cleaned]


def classify_theme(strategy: str, excerpt: str) -> Tuple[str, str]:
    for label, desc, keywords in THEME_RULES.get(strategy, []):
        if any(keyword in excerpt for keyword in keywords):
            return label, desc
    return "其他匹配话术", "这类话术也与当前策略有关，但不落在预设主题里。"


def build_script_catalog(rows: List[Dict[str, str]]) -> List[Dict[str, str]]:
    catalog: List[Dict[str, str]] = []
    for row in rows:
        strategy = row["销售策略"]
        excerpts = split_script_items(row.get("具体话术总结", ""))
        if not excerpts:
            catalog.append(
                {
                    "销售策略": strategy,
                    "分类主题": "未体现明显匹配话术",
                    "主题说明": "该场次没有出现足够清晰、可归因到当前策略的销售话术。",
                    "录音ID": row["录音ID"],
                    "沟通ID": row["沟通ID"],
                    "场景": row["场景"],
                    "客户类型": row["客户类型"],
                    "具体话术片段": row.get("具体话术总结", "") or "未体现明显匹配话术",
                }
            )
            continue

        for excerpt in excerpts:
            theme, desc = classify_theme(strategy, excerpt)
            catalog.append(
                {
                    "销售策略": strategy,
                    "分类主题": theme,
                    "主题说明": desc,
                    "录音ID": row["录音ID"],
                    "沟通ID": row["沟通ID"],
                    "场景": row["场景"],
                    "客户类型": row["客户类型"],
                    "具体话术片段": excerpt,
                }
            )
    return catalog


def escape(value: str) -> str:
    return html.escape(str(value or ""))


def percent(value: int, total: int) -> str:
    return f"{(value / total * 100):.1f}%" if total else "0.0%"


def svg_bar_chart(items: List[Tuple[str, int]], title: str, palette: Dict[str, str], total: int) -> str:
    max_value = max((count for _, count in items), default=1)
    row_height = 42
    height = 48 + len(items) * row_height
    width = 560
    left = 150
    chart_width = 320
    parts = [
        f'<svg viewBox="0 0 {width} {height}" class="chart-svg" role="img" aria-label="{escape(title)}">',
        f'<text x="0" y="24" class="chart-title">{escape(title)}</text>',
    ]
    for idx, (label, count) in enumerate(items):
        y = 44 + idx * row_height
        bar_width = 0 if max_value == 0 else int(chart_width * count / max_value)
        color = palette.get(label, "#46627f")
        parts.append(f'<text x="0" y="{y + 18}" class="chart-label">{escape(label)}</text>')
        parts.append(f'<rect x="{left}" y="{y}" width="{chart_width}" height="20" rx="10" fill="#d8dfdd"></rect>')
        parts.append(f'<rect x="{left}" y="{y}" width="{bar_width}" height="20" rx="10" fill="{color}"></rect>')
        parts.append(f'<text x="{left + chart_width + 12}" y="{y + 15}" class="chart-value">{count}  {percent(count, total)}</text>')
    parts.append("</svg>")
    return "".join(parts)


def heat_color(value: int, max_value: int, hue: str) -> str:
    if value <= 0 or max_value <= 0:
        return "#f4f1ea"
    alpha = 0.16 + (value / max_value) * 0.68
    if hue == "teal":
        return f"rgba(29, 114, 99, {alpha:.2f})"
    if hue == "rust":
        return f"rgba(188, 93, 61, {alpha:.2f})"
    return f"rgba(64, 98, 148, {alpha:.2f})"


def render_heatmap(title: str, row_labels: List[str], col_labels: List[str], matrix: Dict[Tuple[str, str], int], hue: str) -> str:
    max_value = max(matrix.values(), default=0)
    parts = [f'<section class="panel"><div class="panel-head"><h3>{escape(title)}</h3><p>颜色越深，代表该组合出现越多。</p></div><div class="table-wrap"><table class="heatmap"><thead><tr><th>维度</th>']
    for col_label in col_labels:
        parts.append(f"<th>{escape(col_label)}</th>")
    parts.append("</tr></thead><tbody>")
    for row_label in row_labels:
        parts.append(f"<tr><th>{escape(row_label)}</th>")
        for col_label in col_labels:
            value = matrix.get((row_label, col_label), 0)
            color = heat_color(value, max_value, hue)
            parts.append(f'<td style="background:{color}"><span>{value}</span></td>')
        parts.append("</tr>")
    parts.append("</tbody></table></div></section>")
    return "".join(parts)


def top_value(counter: Counter) -> Tuple[str, int]:
    if not counter:
        return "", 0
    return counter.most_common(1)[0]


def dominant_non_unknown(values: Iterable[str]) -> Tuple[str, int]:
    filtered = [value for value in values if value and value != UNKNOWN_LABEL]
    if not filtered:
        return UNKNOWN_LABEL, 0
    return Counter(filtered).most_common(1)[0]


def render_strategy_sections(rows: List[Dict[str, str]], catalog: List[Dict[str, str]]) -> str:
    by_strategy: Dict[str, List[Dict[str, str]]] = defaultdict(list)
    for row in rows:
        by_strategy[row["销售策略"]].append(row)

    catalog_by_strategy: Dict[str, List[Dict[str, str]]] = defaultdict(list)
    for item in catalog:
        catalog_by_strategy[item["销售策略"]].append(item)

    sections: List[str] = []
    for strategy, count in counter_in_order(Counter(row["销售策略"] for row in rows), STRATEGY_ORDER):
        strategy_rows = by_strategy[strategy]
        strategy_catalog = catalog_by_strategy[strategy]

        customer_counter = Counter(row["客户类型"] for row in strategy_rows)
        scene_counter = Counter(row["场景"] for row in strategy_rows)
        industry_counter = Counter(row["行业类型"] for row in strategy_rows if row["行业类型"] and row["行业类型"] != UNKNOWN_LABEL)
        dominant_customer, dominant_customer_count = top_value(customer_counter)
        dominant_scene, dominant_scene_count = top_value(scene_counter)
        dominant_industry, _ = top_value(industry_counter) if industry_counter else (UNKNOWN_LABEL, 0)

        theme_counter = Counter(item["分类主题"] for item in strategy_catalog)
        top_themes = [name for name, _ in theme_counter.most_common(2)]
        summary = (
            f"这个策略在 {count} 个场次里出现，主要面向 {dominant_customer}（{percent(dominant_customer_count, count)}），"
            f"更常发生在 {dominant_scene}（{percent(dominant_scene_count, count)}）。"
        )
        if dominant_industry != UNKNOWN_LABEL:
            summary += f" 从行业侧看，最常见的是 {dominant_industry}。"
        if top_themes:
            summary += f" 话术层面最常见的切口是 {('、'.join(top_themes))}。"

        theme_groups: Dict[str, List[Dict[str, str]]] = defaultdict(list)
        theme_desc: Dict[str, str] = {}
        for item in strategy_catalog:
            theme_groups[item["分类主题"]].append(item)
            theme_desc[item["分类主题"]] = item["主题说明"]

        section_parts = [
            '<section class="strategy-block">',
            '<div class="strategy-head">',
            f'<div><h3>{escape(strategy)}</h3><p>{escape(summary)}</p></div>',
            f'<div class="badge-stack"><span class="badge">{count} 个场次</span><span class="badge ghost">{escape(dominant_customer)}</span><span class="badge ghost">{escape(dominant_scene)}</span></div>',
            "</div>",
            '<div class="theme-grid">',
        ]

        for theme_name, theme_count in sorted(theme_counter.items(), key=lambda item: (-item[1], item[0])):
            section_parts.append(
                f'<div class="theme-chip"><strong>{escape(theme_name)}</strong><span>{theme_count} 条片段</span><p>{escape(theme_desc.get(theme_name, ""))}</p></div>'
            )
        section_parts.append("</div>")

        for idx, (theme_name, items) in enumerate(sorted(theme_groups.items(), key=lambda item: (-len(item[1]), item[0]))):
            open_attr = " open" if idx == 0 else ""
            section_parts.append(f'<details class="theme-detail"{open_attr}><summary>{escape(theme_name)}<span>{len(items)} 条</span></summary>')
            section_parts.append(f'<p class="theme-note">{escape(theme_desc.get(theme_name, ""))}</p>')
            section_parts.append('<div class="excerpt-stack">')
            for item in items:
                meta = f"{item['录音ID']}｜{item['沟通ID']}｜{item['场景']}｜{item['客户类型']}"
                section_parts.append(
                    '<article class="excerpt-card">'
                    f'<div class="excerpt-meta">{escape(meta)}</div>'
                    f'<div class="excerpt-body">{escape(item["具体话术片段"])}</div>'
                    "</article>"
                )
            section_parts.append("</div></details>")

        section_parts.append("</section>")
        sections.append("".join(section_parts))

    return "".join(sections)


def render_insights(rows: List[Dict[str, str]], scene_counts: Counter, customer_counts: Counter, strategy_counts: Counter) -> str:
    total = len(rows)
    top_scene, top_scene_count = top_value(scene_counts)
    top_customer, top_customer_count = top_value(customer_counts)
    top_strategy, top_strategy_count = top_value(strategy_counts)

    cards = [
        ("主场景", f"{top_scene} {percent(top_scene_count, total)}", "这说明样本里更多是已经进入较长交流或较完整讲解的沟通。"),
        ("主客户类型", f"{top_customer} {percent(top_customer_count, total)}", "客户心理状态对策略分布影响非常明显，后续培训可以围绕这个群体重点拆解。"),
        ("主销售策略", f"{top_strategy} {percent(top_strategy_count, total)}", "策略不是平均分散的，说明一线实际打法高度集中在少数几类处理方式。"),
    ]
    return "".join(
        [
            '<section class="insight-grid">'
            + "".join(
                f'<article class="insight-card"><div class="insight-kicker">{escape(title)}</div><h3>{escape(metric)}</h3><p>{escape(body)}</p></article>'
                for title, metric, body in cards
            )
            + "</section>"
        ]
    )


def build_html_report(
    rows: List[Dict[str, str]],
    catalog: List[Dict[str, str]],
    source_file: Path,
) -> str:
    total_rows = len(rows)
    unique_recordings = len({row["录音ID"] for row in rows})
    unique_scene_ids = len({(row["录音ID"], row["沟通ID"]) for row in rows})

    scene_counts = Counter(row["场景"] for row in rows)
    customer_counts = Counter(row["客户类型"] for row in rows)
    strategy_counts = Counter(row["销售策略"] for row in rows)
    industry_counts = Counter(row["行业类型"] for row in rows if row["行业类型"] and row["行业类型"] != UNKNOWN_LABEL)
    product_counts = Counter(row["产品类型"] for row in rows if row["产品类型"] and row["产品类型"] != UNKNOWN_LABEL)

    scene_items = counter_in_order(scene_counts, SCENE_ORDER)
    customer_items = counter_in_order(customer_counts, CUSTOMER_ORDER)
    strategy_items = counter_in_order(strategy_counts, STRATEGY_ORDER)
    industry_items = industry_counts.most_common(8)
    product_items = product_counts.most_common(8)

    scene_labels, strategy_labels, scene_strategy = build_matrix(rows, "场景", "销售策略", SCENE_ORDER, STRATEGY_ORDER)
    customer_labels, strategy_labels_2, customer_strategy = build_matrix(rows, "客户类型", "销售策略", CUSTOMER_ORDER, STRATEGY_ORDER)
    scene_labels_2, customer_labels_2, scene_customer = build_matrix(rows, "场景", "客户类型", SCENE_ORDER, CUSTOMER_ORDER)
    industry_rows = [row for row in rows if row["行业类型"] and row["行业类型"] != UNKNOWN_LABEL]
    product_rows = [row for row in rows if row["产品类型"] and row["产品类型"] != UNKNOWN_LABEL]
    industry_labels, industry_strategy_labels, industry_strategy = build_matrix(industry_rows, "行业类型", "销售策略", [], STRATEGY_ORDER)
    generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>销售样本策略统计报告</title>
  <style>
    :root {{
      --bg: #efe8dc;
      --panel: rgba(255,255,255,0.76);
      --ink: #20323a;
      --muted: #5f6f77;
      --line: rgba(32,50,58,0.12);
      --accent: #195c57;
      --accent-soft: #d9ebe8;
      --rust: #b75b3a;
      --sand: #f7f0e7;
      --shadow: 0 22px 48px rgba(28,39,43,0.10);
      --radius: 24px;
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      font-family: "Segoe UI Variable Text", "Microsoft YaHei UI", "PingFang SC", sans-serif;
      color: var(--ink);
      background:
        radial-gradient(circle at top left, rgba(25,92,87,0.18), transparent 32%),
        radial-gradient(circle at top right, rgba(183,91,58,0.16), transparent 28%),
        linear-gradient(180deg, #f6f2ec 0%, var(--bg) 100%);
    }}
    .shell {{
      width: min(1440px, calc(100vw - 48px));
      margin: 24px auto 56px;
    }}
    .hero {{
      position: relative;
      overflow: hidden;
      padding: 34px 34px 28px;
      border-radius: 30px;
      background:
        linear-gradient(135deg, rgba(255,255,255,0.85), rgba(255,255,255,0.62)),
        linear-gradient(135deg, rgba(25,92,87,0.14), rgba(183,91,58,0.10));
      box-shadow: var(--shadow);
      border: 1px solid rgba(255,255,255,0.65);
    }}
    .hero::after {{
      content: "";
      position: absolute;
      right: -80px;
      top: -100px;
      width: 280px;
      height: 280px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(25,92,87,0.22), transparent 70%);
    }}
    .hero h1 {{
      margin: 0;
      font-family: "Bahnschrift", "Segoe UI Variable Display", "Microsoft YaHei UI", sans-serif;
      font-size: clamp(32px, 4vw, 52px);
      line-height: 1.02;
      letter-spacing: 0.02em;
    }}
    .hero p {{
      margin: 14px 0 0;
      max-width: 920px;
      color: var(--muted);
      font-size: 15px;
      line-height: 1.8;
    }}
    .meta-row {{
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      margin-top: 18px;
    }}
    .meta-pill {{
      padding: 8px 14px;
      border-radius: 999px;
      background: rgba(255,255,255,0.72);
      border: 1px solid rgba(32,50,58,0.08);
      font-size: 13px;
      color: #30464f;
    }}
    .stat-grid {{
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 16px;
      margin-top: 22px;
    }}
    .stat-card {{
      padding: 20px;
      border-radius: 22px;
      background: rgba(250,247,242,0.86);
      border: 1px solid rgba(32,50,58,0.08);
    }}
    .stat-card .label {{
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: 0.12em;
      color: var(--muted);
    }}
    .stat-card .value {{
      margin-top: 10px;
      font-size: 34px;
      font-weight: 700;
      line-height: 1;
    }}
    .stat-card .sub {{
      margin-top: 8px;
      color: var(--muted);
      font-size: 13px;
      line-height: 1.6;
    }}
    .insight-grid {{
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 16px;
      margin-top: 20px;
    }}
    .insight-card {{
      background: linear-gradient(180deg, rgba(255,255,255,0.88), rgba(255,255,255,0.68));
      border: 1px solid rgba(32,50,58,0.08);
      border-radius: 22px;
      padding: 18px 18px 16px;
      box-shadow: 0 14px 32px rgba(31,45,48,0.08);
    }}
    .insight-kicker {{
      font-size: 12px;
      letter-spacing: 0.12em;
      text-transform: uppercase;
      color: var(--muted);
    }}
    .insight-card h3 {{
      margin: 10px 0 8px;
      font-size: 21px;
      line-height: 1.35;
    }}
    .insight-card p {{
      margin: 0;
      color: var(--muted);
      line-height: 1.7;
      font-size: 14px;
    }}
    .section-title {{
      margin: 34px 0 14px;
      font-size: 24px;
      letter-spacing: 0.01em;
    }}
    .panel-grid {{
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 18px;
    }}
    .panel-grid.overview {{
      grid-template-columns: repeat(3, minmax(0, 1fr));
      align-items: stretch;
    }}
    .panel-grid.overview .panel {{
      padding: 24px;
      min-height: 420px;
    }}
    .panel-grid.overview .panel-head h3 {{
      font-size: 20px;
    }}
    .panel-grid.overview .panel-head p {{
      font-size: 14px;
    }}
    .panel {{
      background: var(--panel);
      border-radius: var(--radius);
      border: 1px solid rgba(255,255,255,0.7);
      box-shadow: var(--shadow);
      padding: 22px;
      backdrop-filter: blur(16px);
    }}
    .panel-head {{
      display: flex;
      flex-direction: column;
      gap: 6px;
      margin-bottom: 10px;
    }}
    .panel-head h3 {{
      margin: 0;
      font-size: 20px;
    }}
    .panel-head p {{
      margin: 0;
      color: var(--muted);
      font-size: 14px;
      line-height: 1.6;
    }}
    .chart-svg {{
      width: 100%;
      height: auto;
      display: block;
    }}
    .chart-title {{
      font-size: 18px;
      fill: #20323a;
      font-weight: 700;
    }}
    .chart-label {{
      font-size: 13px;
      fill: #425962;
    }}
    .chart-value {{
      font-size: 13px;
      fill: #20323a;
      font-weight: 600;
    }}
    .table-wrap {{
      overflow-x: auto;
    }}
    table {{
      width: 100%;
      border-collapse: collapse;
    }}
    .heatmap th,
    .heatmap td {{
      border-bottom: 1px solid var(--line);
      padding: 12px 10px;
      text-align: center;
      font-size: 13px;
    }}
    .heatmap th:first-child,
    .heatmap td:first-child {{
      text-align: left;
      min-width: 140px;
      position: sticky;
      left: 0;
      background: rgba(247,240,231,0.97);
    }}
    .heatmap thead th {{
      position: sticky;
      top: 0;
      background: rgba(247,240,231,0.97);
      z-index: 2;
    }}
    .heatmap td span {{
      display: inline-flex;
      width: 100%;
      justify-content: center;
      align-items: center;
      min-height: 26px;
      border-radius: 10px;
      font-weight: 700;
      color: #213138;
    }}
    .strategy-block {{
      margin-top: 20px;
      padding: 24px;
      border-radius: 28px;
      background: linear-gradient(180deg, rgba(255,255,255,0.84), rgba(248,244,236,0.82));
      box-shadow: var(--shadow);
      border: 1px solid rgba(255,255,255,0.7);
    }}
    .strategy-head {{
      display: flex;
      justify-content: space-between;
      gap: 18px;
      align-items: flex-start;
    }}
    .strategy-head h3 {{
      margin: 0;
      font-size: 28px;
    }}
    .strategy-head p {{
      margin: 10px 0 0;
      max-width: 900px;
      color: var(--muted);
      line-height: 1.8;
      font-size: 14px;
    }}
    .badge-stack {{
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      justify-content: flex-end;
    }}
    .badge {{
      padding: 8px 12px;
      border-radius: 999px;
      background: var(--accent);
      color: white;
      font-size: 12px;
      font-weight: 700;
      letter-spacing: 0.06em;
    }}
    .badge.ghost {{
      background: rgba(25,92,87,0.10);
      color: var(--accent);
      border: 1px solid rgba(25,92,87,0.14);
    }}
    .theme-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 14px;
      margin-top: 18px;
    }}
    .theme-chip {{
      border-radius: 20px;
      background: rgba(255,255,255,0.78);
      border: 1px solid rgba(32,50,58,0.08);
      padding: 16px;
    }}
    .theme-chip strong {{
      display: block;
      font-size: 16px;
    }}
    .theme-chip span {{
      display: inline-block;
      margin-top: 8px;
      color: var(--rust);
      font-size: 12px;
      font-weight: 700;
      letter-spacing: 0.08em;
    }}
    .theme-chip p {{
      margin: 10px 0 0;
      color: var(--muted);
      line-height: 1.7;
      font-size: 13px;
    }}
    .theme-detail {{
      margin-top: 14px;
      border-radius: 20px;
      background: rgba(247,240,231,0.80);
      border: 1px solid rgba(32,50,58,0.08);
      overflow: hidden;
    }}
    .theme-detail summary {{
      cursor: pointer;
      list-style: none;
      display: flex;
      justify-content: space-between;
      gap: 12px;
      padding: 16px 18px;
      font-weight: 700;
      font-size: 15px;
    }}
    .theme-detail summary span {{
      color: var(--rust);
      font-size: 12px;
      letter-spacing: 0.08em;
      text-transform: uppercase;
    }}
    .theme-note {{
      margin: 0;
      padding: 0 18px 10px;
      color: var(--muted);
      line-height: 1.7;
      font-size: 13px;
    }}
    .excerpt-stack {{
      padding: 0 18px 18px;
      display: grid;
      gap: 12px;
    }}
    .excerpt-card {{
      border-radius: 16px;
      background: rgba(255,255,255,0.84);
      border: 1px solid rgba(32,50,58,0.08);
      padding: 14px;
    }}
    .excerpt-meta {{
      font-size: 12px;
      color: var(--muted);
      letter-spacing: 0.04em;
    }}
    .excerpt-body {{
      margin-top: 8px;
      font-size: 14px;
      line-height: 1.8;
      color: #22353d;
    }}
    .footer-note {{
      margin-top: 28px;
      padding: 20px 22px;
      border-radius: 20px;
      background: rgba(255,255,255,0.74);
      border: 1px solid rgba(32,50,58,0.08);
      color: var(--muted);
      line-height: 1.8;
      font-size: 14px;
    }}
    @media (max-width: 1100px) {{
      .stat-grid,
      .insight-grid,
      .panel-grid,
      .panel-grid.overview {{
        grid-template-columns: 1fr 1fr;
      }}
      .strategy-head {{
        flex-direction: column;
      }}
      .badge-stack {{
        justify-content: flex-start;
      }}
    }}
    @media (max-width: 760px) {{
      .shell {{
        width: min(100vw - 24px, 100%);
        margin: 12px auto 36px;
      }}
      .hero,
      .panel,
      .strategy-block {{
        padding: 18px;
      }}
      .stat-grid,
      .insight-grid,
      .panel-grid,
      .panel-grid.overview {{
        grid-template-columns: 1fr;
      }}
      .hero h1 {{
        font-size: 32px;
      }}
    }}
  </style>
</head>
<body>
  <main class="shell">
    <section class="hero">
      <h1>销售录音样本策略观察板</h1>
      <p>这份报告基于 <strong>{unique_recordings} 条抽样录音</strong> 里已经跑完的 <strong>{unique_scene_ids} 个沟通场次</strong>，围绕场景、客户类型、行业产品、销售策略和具体话术做分布统计与策略话术归档。所有统计均按“沟通场次”口径计算，因此一个录音里被切出的多个场次会分别计入。</p>
      <div class="meta-row">
        <span class="meta-pill">源文件：{escape(source_file.name)}</span>
        <span class="meta-pill">生成时间：{escape(generated_at)}</span>
        <span class="meta-pill">项目负责人：刘东星</span>
      </div>
      <div class="stat-grid">
        <article class="stat-card"><div class="label">已完成录音</div><div class="value">{unique_recordings}</div><div class="sub">本轮 partial 文件已覆盖的样本录音数。</div></article>
        <article class="stat-card"><div class="label">沟通场次</div><div class="value">{unique_scene_ids}</div><div class="sub">统计分析统一按场次口径做，不按文件口径混算。</div></article>
        <article class="stat-card"><div class="label">销售策略种类</div><div class="value">{sum(1 for _, count in strategy_items if count > 0)}</div><div class="sub">当前样本里实际出现过的策略种类数。</div></article>
        <article class="stat-card"><div class="label">话术片段</div><div class="value">{len(catalog)}</div><div class="sub">按策略拆出的可归档话术片段数量，包含“未体现明显匹配话术”。</div></article>
      </div>
    </section>

    {render_insights(rows, scene_counts, customer_counts, strategy_counts)}

    <h2 class="section-title">分布总览</h2>
    <section class="panel-grid overview">
      <section class="panel"><div class="panel-head"><h3>场景分布</h3><p>深度会谈场景明显占主导，说明当前已跑完的样本更偏长时沟通与完整讲解型。</p></div>{svg_bar_chart(scene_items, "场景分布", SCENE_COLORS, total_rows)}</section>
      <section class="panel"><div class="panel-head"><h3>客户类型分布</h3><p>保守观望型、价格敏感型是最主要的两类客户，后续培训可以重点围绕这两类客户做打法拆解。</p></div>{svg_bar_chart(customer_items, "客户类型分布", CUSTOMER_COLORS, total_rows)}</section>
      <section class="panel"><div class="panel-head"><h3>销售策略分布</h3><p>策略明显集中在“信任建立”“成本重构”“试探教育”几类，说明当前一线对风险顾虑和成本顾虑处理最频繁。</p></div>{svg_bar_chart(strategy_items, "销售策略分布", STRATEGY_COLORS, total_rows)}</section>
      <section class="panel"><div class="panel-head"><h3>行业类型分布</h3><p>这里统计的是已经被模型明确识别出来的行业类型，能帮助判断策略更常落在哪类经营主体上。</p></div>{svg_bar_chart(industry_items or [("未能根据知识库判断", 0)], "行业类型 Top", {item[0]: "#7a5c43" for item in industry_items}, total_rows)}</section>
      <section class="panel"><div class="panel-head"><h3>产品类型分布</h3><p>这里统计的是主营产品或服务方向，和行业统计一起看更容易理解样本中的经营结构。</p></div>{svg_bar_chart(product_items or [("未能根据知识库判断", 0)], "产品类型 Top", {item[0]: "#8b5a3c" for item in product_items}, total_rows)}</section>
    </section>

    <h2 class="section-title">交叉分析</h2>
    <section class="panel-grid">
      {render_heatmap("场景 × 销售策略", scene_labels, strategy_labels, scene_strategy, "teal")}
      {render_heatmap("客户类型 × 销售策略", customer_labels, strategy_labels_2, customer_strategy, "rust")}
      {render_heatmap("场景 × 客户类型", scene_labels_2, customer_labels_2, scene_customer, "blue")}
      {render_heatmap("行业类型 × 销售策略", industry_labels, industry_strategy_labels, industry_strategy, "rust")}
    </section>

    <h2 class="section-title">按策略整理的话术库</h2>
    <section>
      {render_strategy_sections(rows, catalog)}
    </section>

    <div class="footer-note">
      这份报告只基于已经成功跑完的 partial 样本生成。后续如果你把剩余录音续跑完成，只需要用新的完整汇总文件重新执行同一个报告脚本，就能自动刷新统计、交叉矩阵和话术库。
    </div>
  </main>
</body>
</html>
"""


def main() -> int:
    parser = argparse.ArgumentParser(description="只根据样本汇总 CSV 生成 HTML 看板")
    parser.add_argument("--input", default=str(DEFAULT_INPUT), help="样本汇总 CSV 路径")
    parser.add_argument("--output-html", default=str(DEFAULT_OUTPUT_HTML), help="HTML 看板输出路径")
    args = parser.parse_args()

    input_path = Path(args.input)
    output_html = Path(args.output_html)
    output_html.parent.mkdir(parents=True, exist_ok=True)

    rows = normalize_rows(load_rows(input_path))
    catalog = build_script_catalog(rows)

    html_report = build_html_report(rows, catalog, input_path)
    output_html.write_text(html_report, encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
